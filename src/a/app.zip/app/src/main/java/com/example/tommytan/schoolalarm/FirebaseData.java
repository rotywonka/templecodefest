package com.example.tommytan.schoolalarm;

/**
 * Created by tommytan on 4/14/18.
 */

public class FirebaseData {
    public boolean ongoingEvent;

}
